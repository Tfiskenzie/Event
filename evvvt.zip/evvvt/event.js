function redirectToPage(){
    window.location.href = "Signup.html";
}